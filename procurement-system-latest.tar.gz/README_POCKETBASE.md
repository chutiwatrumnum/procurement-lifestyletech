# 🗄️ PocketBase Setup for Procurement System

สร้างโดย หมี 🐻 | 2026-02-11

ระบบจัดซื้อนี้รองรับการเชื่อมต่อกับ **PocketBase** เป็น Backend จริงค่ะ เพื่อให้พี่เจมส์สามารถเก็บข้อมูลและ Login ได้แบบ Real-time

---

## 🚀 วิธีติดตั้ง Backend

### 1. ดาวน์โหลดและรัน PocketBase
1. เข้าไปที่ [PocketBase.io](https://pocketbase.io/docs/)
2. ดาวน์โหลดตัว executable ตาม OS ของพี่เจมส์ (Mac M1 เลือก `darwin_arm64`)
3. รันด้วยคำสั่ง:
   ```bash
   ./pocketbase serve
   ```
4. เข้าหน้า Admin ที่ [http://127.0.0.1:8090/_/](http://127.0.0.1:8090/_/) และสร้าง Admin account ครั้งแรกค่ะ

### 2. นำเข้าโครงสร้างฐานข้อมูล (Import Schema)
หมีเตรียมไฟล์โครงสร้างไว้ให้แล้วค่ะ:
1. ในหน้า Admin PocketBase ไปที่ **Settings > Import collections**
2. กดปุ่ม "Load from JSON file"
3. เลือกไฟล์ `pb_schema.json` ในโฟลเดอร์โปรเจคนี้
4. กด **Import**

### 3. ตั้งค่า API URL ใน Frontend
1. เปิดไฟล์ `.env` ในโฟลเดอร์โปรเจค
2. ตรวจสอบว่า `VITE_POCKETBASE_URL` ตรงกับ URL ของ PocketBase (ปกติคือ `http://127.0.0.1:8090`)

### 3. นำเข้าข้อมูลเริ่มต้น (Seed Mockup Data)
เพื่อให้ระบบไม่ว่างเปล่า หมีเตรียมข้อมูลโครงการและผู้ขายไว้ให้แล้วค่ะ:
1. ในหน้า Admin PocketBase ไปที่ตาราง `projects` และ `vendors`
2. พี่เจมส์สามารถกดสร้างข้อมูลตามไฟล์ `seed_projects.json` และ `seed_vendors.json` ได้เลย
3. หรือถ้าพี่เจมส์ลง `node` ในเครื่อง สามารถรันคำสั่ง:
   ```bash
   node seed_db.js
   ```
   (หมายเหตุ: ต้องเปิดสิทธิ์ Create Rule ของตารางเป็นแบบ Public ชั่วคราวเพื่อให้สคริปต์ทำงานได้ค่ะ)

---

## 🔑 การใช้งานระบบ Login

### วิธีที่ 1: สร้าง User จริงใน PocketBase
1. ไปที่ collection `users` ในหน้า Admin
2. กด **New record**
3. กรอก `email`, `password`, `name`, และเลือก `role`
4. ใช้ account นี้ Login เข้าหน้าเว็บได้เลยค่ะ

### วิธีที่ 2: ใช้ Demo (ถ้ายังไม่รัน PocketBase)
- ระบบยังรองรับการ Login แบบ Demo เหมือนเดิมค่ะ โดยใช้:
  - Email: `demo@example.com`
  - Password: `demo1234`
- ข้อมูลที่เห็นจะเป็น Mock Data แต่ถ้าพี่เจมส์รัน PocketBase สำเร็จ ข้อมูลจะถูกดึงจาก Database จริงอัตโนมัติค่ะ

---

## 📊 โครงสร้างตาราง (Collections)
- `users`: เก็บข้อมูลพนักงานและสิทธิ์การใช้งาน
- `projects`: ข้อมูลโครงการก่อสร้างและงบประมาณ
- `vendors`: รายชื่อผู้ขายและข้อมูลติดต่อ
- `purchase_requests`: ใบขอซื้อ (PR) และสถานะการอนุมัติ
- `pr_items`: รายการสินค้าในใบขอซื้อแต่ละใบ
- `purchase_orders`: ใบสั่งซื้อ (PO) ที่สร้างจาก PR

ถ้าพี่เจมส์ติดขัดตรงไหนในการตั้งค่า บอกหมีได้เลยนะคะ! ✨🐻
